package com.validator;

import static org.junit.Assert.assertEquals;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.junit4.SpringRunner;

@RunWith(SpringRunner.class)
@SpringBootTest
public class RoyalmailValidatorApplicationTests {

	@Autowired
	RoyalMailValidatorController controller;
	
	@Autowired
	RoyalMailValidatorService royalMailValidatorService;
	
	
	public static final String oneDBarCode = "AB473124829GB";
	
	@Test
	public void testBarcode() throws Exception {
		
		System.out.println("Is Barcode Valid? --> "+controller.barCodeValidator(oneDBarCode).getIsValidBarCode());
		assertEquals(controller.barCodeValidator(oneDBarCode).getIsValidBarCode(), true);
		
	}
}
