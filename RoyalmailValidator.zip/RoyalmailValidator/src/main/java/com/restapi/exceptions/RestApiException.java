package com.restapi.exceptions;

public class RestApiException extends RuntimeException{
	
	public 	RestApiException(String message) {
		super(message);
	}

	public 	RestApiException(String message, Throwable rootCause) {
		super(message, rootCause);
	}
}
