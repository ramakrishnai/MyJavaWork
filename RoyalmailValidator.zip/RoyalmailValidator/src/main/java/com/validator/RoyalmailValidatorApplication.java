package com.validator;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class RoyalmailValidatorApplication {

	public static void main(String[] args) {
		SpringApplication.run(RoyalmailValidatorApplication.class, args);
	}

}
