package com.validator;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.restapi.exceptions.RestApiException;

@RestController
public class RoyalMailValidatorController {
	
	@Autowired
	RoyalMailValidatorService royalMailValidatorService;
	
	@RequestMapping(value="/validator/{oneDBarCode}", method = RequestMethod.GET)
	public BarCodeInfo barCodeValidator(@PathVariable String oneDBarCode) {
		
		BarCodeInfo barCode = new BarCodeInfo();
		barCode.setBarCode(oneDBarCode);
		try {
			String result = royalMailValidatorService.checkDigitValidation(oneDBarCode);
		
			//Barcode Validation
			switch(result) {
			
				case "CHECK_DIGIT_INPUT_BARCODE_ERROR": 
					barCode.setIsValidBarCode(false);
					barCode.setError("Check Digit is invalid from Barcode");
					break;
				case "PREFIX_FROM_INPUT_BARCODE_ERROR": 
					barCode.setIsValidBarCode(false);
					barCode.setError("Prefix is invalid from Barcode");
					break;
				case "SERIAL_NUMBER_FROM_INPUT_BARCODE_ERROR": 
					barCode.setIsValidBarCode(false);
					barCode.setError("Serial Number is invalid from Barcode");
					break;
				case "COUNTRY_CODE_FROM_INPUT_BARCODE_ERROR": 
					barCode.setIsValidBarCode(false);
					barCode.setError("Country Code is invalid from Barcode");
					break;
				case "INVALID_BARCODE_LENGTH": 
					barCode.setIsValidBarCode(false);
					barCode.setError("Barcode Length is invalid");
					break;
				case "VALID_BARCODE": 
					barCode.setIsValidBarCode(true);
					barCode.setError("None");
					break;
			}
		} catch (Exception ex) {
			throw new RestApiException(ex.getMessage());
		}
		
		return barCode;
	}
}
