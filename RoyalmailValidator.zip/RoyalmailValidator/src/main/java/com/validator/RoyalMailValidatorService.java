package com.validator;

import java.util.Arrays;

import org.springframework.stereotype.Service;

@Service
public class RoyalMailValidatorService {
	
	
	public String checkDigitValidation(String oneDBarCode) {
		
		//System.out.println(oneDBarCode);
		long sum = 0;
		int weights[] = {8, 6, 4, 2, 3, 5, 9, 7};
		String serialNumber = oneDBarCode.substring(2, 10);
		
		char slno[] = serialNumber.toCharArray();
		Arrays.asList(slno);
		for(int i=0; i<=7; i++) {
			sum = sum + (Integer.parseInt(String.valueOf(serialNumber.charAt(i))) * weights[i]);
		}
		
		//To check the 2 chars Prefix range AA to ZZ validation
		boolean prefix = oneDBarCode.substring(0, 2).matches("^[A-Z]*$");
		if(!prefix) {
			return "PREFIX_FROM_INPUT_BARCODE_ERROR";
		}
		
		//Validate input Barcode.
		if(oneDBarCode.length() != 13) {
			return "INVALID_BARCODE_LENGTH";
		}
		
		//Validation for serial number
		boolean serialNo = serialNumber.matches("^[0-9]*$");
		if(!serialNo) {
			return "SERIAL_NUMBER_FROM_INPUT_BARCODE_ERROR";
		}
		
		//Validation for Country Code - GB
		String countryCode = oneDBarCode.substring(11, 13);
		if(!countryCode.equals("GB")) {
			return "COUNTRY_CODE_FROM_INPUT_BARCODE_ERROR";
		}
		
		//Check Digit calculation before validation. 
		long checkDigitFound = Integer.parseInt(oneDBarCode.substring(10,11));
		long checkDigit = 0L;
		checkDigit = 11 - (sum % 11);
		
		if(checkDigit == 10) {
			checkDigit = 0;
		} 
		else if(checkDigit == 11) {
			checkDigit = 5;
		} 
		
		//validation for check-digit with input.
		if(checkDigit != checkDigitFound) {
			return "CHECK_DIGIT_INPUT_BARCODE_ERROR";
		}
		return "VALID_BARCODE";
	}

}
