package com.validator;

public class BarCodeInfo {
	
	private String barCode;
	private boolean isValidBarCode;
	private String error;
	
	public String getBarCode() {
		return barCode;
	}
	public void setBarCode(String barCode) {
		this.barCode = barCode;
	}
	public boolean getIsValidBarCode() {
		return isValidBarCode;
	}
	public void setIsValidBarCode(boolean isValidBarCode) {
		this.isValidBarCode = isValidBarCode;
	}
	public String getError() {
		return error;
	}
	public void setError(String error) {
		this.error = error;
	}
	
	

}
